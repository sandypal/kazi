import React from 'react';
function HeroBanner () {
	return <div>
<div className="banner_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="banner_text">
                     <h1>Extremis</h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
}
export default HeroBanner;