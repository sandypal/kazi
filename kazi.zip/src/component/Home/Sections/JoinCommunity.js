import React from 'react';
function JoinCommunity () {
	return <div>
<section className="join_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="join_text">
                     <h1>JOIN THE COMMUNITY</h1>
                  </div>
               </div>
            </div>
         </div>
      </section>
    </div>
}
export default JoinCommunity;