import React from 'react';
import blacknet1 from "../../Images/blacknet1.png";
import alice from "../../Images//alice.png";
function Allcards () {
	return <div>

<div className="sell_box">
   <div className="row">
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="sell_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="sell_list_box">
               <ul>
                  <li>FACTION:<br></br><span>BLACKNET</span></li>
                  <li>CARD TYPE:<br></br><span>UPGRADE 1</span></li>
                  <li>RANK: <span>PRIVATE</span></li>
               </ul>
            </div>
            <div className="sell_card_btn">
               <ul>
                  <li><a className="btn" href="/sell-card-details">DETAILS</a></li>
                  <li><a className="btn" href="/sell-card-details">SELL CARD</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</div>
     </div>
     }
     export default Allcards;