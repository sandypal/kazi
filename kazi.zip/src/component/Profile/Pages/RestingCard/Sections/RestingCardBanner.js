import React from 'react';
function RestingCardBanner(){
 return <div>
<div className="resting_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="resting_text">
                     <h1>Resting Card </h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
 </div>


}
export default RestingCardBanner;