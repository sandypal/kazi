import React from 'react';
import PromoteCardTab from '../Sections/PromoteCardTab';
function PromoteTaxt(){
 return <div>
<section className="promote_text">
         <div className="container">
            <div className="row">
               <div className="col-md-10 offset-md-1">
                  <div className="promote_tab">
                              <PromoteCardTab/>
                  </div>
               </div>
            </div>
         </div>
      </section>
 </div>
 

}
export default PromoteTaxt;