import React from 'react';
import ConfirmBanner from '../Confirm/Sections/ConfirmBanner';
import ConfirmText from '../Confirm/Sections/ConfirmText';
import '../Confirm/Confirm.css';
function Confirm(){
 return <div>
<ConfirmBanner/>
<ConfirmText/>


 </div>


}
export default Confirm;