import React from 'react';
import PromoteBanner from '../Promote/Sections/PromoteBanner';
import PromoteTaxt from '../Promote/Sections/PromoteTaxt';
import '../Promote/Promote.css';
function Promote(){
 return <div>
<PromoteBanner/>
<PromoteTaxt/>
</div>


}
export default Promote;