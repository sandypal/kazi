import React from 'react';
import WarBattleBanner from '../WarBattlefield/Sections/WarBattleBanner';
import WarBattleText from '../WarBattlefield/Sections/WarBattleText';
import CardTab from '../WarBattlefield/Sections/CardTab';
function WarBattlefield(){
 return <div>
<WarBattleBanner/>
<WarBattleText/>
<CardTab/>

 </div>


}
export default WarBattlefield;