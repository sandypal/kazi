import React from 'react';
import RenameBanner from '../Rename/Sections/RenameBanner';
import RenameTaxt from '../Rename/Sections/RenameTaxt';
import '../Rename/Rename.css';
function Rename(){
 return <div>
<RenameBanner/>
<RenameTaxt/>
</div>


}
export default Rename;