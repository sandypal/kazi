import React from 'react';
function RenameConfirmBanner(){
 return <div>
<div className="promote_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="promote_text">
                     <h1>RENAME CARDS</h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
 </div>


}
export default RenameConfirmBanner;