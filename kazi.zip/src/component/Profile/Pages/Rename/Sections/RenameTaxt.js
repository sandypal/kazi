import React from 'react';
import RenameCardTab from '../Sections/RenameCardTab';
function RenameTaxt(){
 return <div>
<section className="promote_text">
         <div className="container">
            <div className="row">
               <div className="col-md-10 offset-md-1">
                  <div className="promote_tab">
                              <RenameCardTab/>
                  </div>
               </div>
            </div>
         </div>
      </section>
 </div>
 

}
export default RenameTaxt;