import React from 'react';
import blacknet1 from "../../Images/blacknet1.png";
import alice from "../../Images/alice.png";
function Allcards () {
	return <div>
         <div className="content_box">

   <div className="row">
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/rename-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/rename-confirm">RENAME</a></li>
            </ul>
         </div>
         </div>
      </div>
      
   </div>
</div>
     </div>
     }
     export default Allcards;