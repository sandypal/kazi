import React from 'react';
import MutateBanner from '../Mutate/Sections/MutateBanner';
import MutateTaxt from '../Mutate/Sections/MutateTaxt';
import '../Mutate/Mutate.css';
function Mutate(){
 return <div>
<MutateBanner/>
<MutateTaxt/>
</div>


}
export default Mutate;