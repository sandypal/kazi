import React from 'react';
import MutateCardTab from '../Sections/MutateCardTab';
function MutateTaxt(){
 return <div>
<section className="promote_text">
         <div className="container">
            <div className="row">
               <div className="col-md-10 offset-md-1">
                  <div className="promote_tab">
                              <MutateCardTab/>
                  </div>
               </div>
            </div>
         </div>
      </section>
 </div>
 

}
export default MutateTaxt;