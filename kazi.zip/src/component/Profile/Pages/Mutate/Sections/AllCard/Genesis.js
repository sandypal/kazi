import React from 'react';
import blacknet1 from "../../Images/blacknet1.png";
import alice from "../../Images/alice.png";
function Genesis () {
	return <div>
<div className="scroll_link">
<ul>
        <li><a href="#type1">Type 1</a></li>
        <li><a href="#type2">Type 2</a></li>
        <li><a href="#type3">Type 3</a></li>
        <li><a href="#type4">Type 4</a></li>
        <li><a href="#type5">Type 5</a></li>
        <li><a href="#type6">Type 6</a></li>
        <li><a href="#type7">Type 7</a></li>
        <li><a href="#type8">Type 8</a></li>
      </ul> 
    </div>
    <div className="content_box">

    <div className="row">
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={blacknet1}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>BLACKNET</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="promote_tab">
         <img src={alice}/>
         <h4>CARD NAME</h4>
         <div class="list_box">
            <ul>
               <li><span>ALICE</span></li>
               <li><span>Rank:</span> Private</li>
               <li>CARD TYPE</li>
               </ul>
         </div>
         <div className="promote_btn">
            <ul>
               <li><a className="btn" href="/mutate-confirm">CARD DETAILS</a></li>
               <li><a className="btn" href="/mutate-confirm">MUTATE</a></li>
            </ul>
         </div>
         </div>
      </div>
      
   </div>
</div>
     </div>
     }
     export default Genesis;