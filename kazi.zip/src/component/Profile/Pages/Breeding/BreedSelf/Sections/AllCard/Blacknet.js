import React from 'react';
import blacknet1 from "../../Images/blacknet1.png";
import alice from "../../Images/alice.png";
function Blacknet () {
	return <div>
          <div className="scroll_link">
      <ul>
        <li><a href="#type1">Type 1</a></li>
        <li><a href="#type2">Type 2</a></li>
        <li><a href="#type3">Type 3</a></li>
        <li><a href="#type4">Type 4</a></li>
        <li><a href="#type5">Type 5</a></li>
        <li><a href="#type6">Type 6</a></li>
        <li><a href="#type7">Type 7</a></li>
        <li><a href="#type8">Type 8</a></li>
      </ul> 
    </div>
    <div className="content_box">

<div className="row">
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={blacknet1}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
             
              </div>
      </div>
   </div>
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={alice}/>
         <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
             
              </div>
      </div>
   </div>
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={blacknet1}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
             
              </div>
      </div>
   </div>
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={alice}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
              
              </div>
      </div>
   </div>
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={blacknet1}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
              
              </div>
      </div>
   </div>
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={alice}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
             
              </div>
      </div>
   </div><div className="col-md-6">
      <div className="breeding_lab">
      <img src={blacknet1}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
            
              </div>
      </div>
   </div>
   <div className="col-md-6">
      <div className="breeding_lab">
      <img src={alice}/>
      <h4>CARD NAME</h4>
      <h5>BLACKNET</h5>
      <div class="list_box">
         <ul>
            <li><span>Rank:</span> Private</li>
            <li><span>Type:</span> Gen 1</li>
            <li><span>IQ:</span> 101</li>
            <li><span>Potential:</span> 101</li>
            <li><span>EQ:</span> 101</li>
            <li><span>Wisdom:</span> 101</li>
            <li><span>Melee:</span> 101</li>
            <li><span>Leadership:</span> 101</li>
            <li><span>Weapon:</span> 101</li>
            <li><span>Feature 9:</span> 101</li>                              
         </ul>
      </div>
      <div className="bettle_btn">
              <a className="btn" href="#">SELECT</a>
              
              </div>
      </div>
   </div>
   
</div>
</div>
     </div>
     }
     export default Blacknet;