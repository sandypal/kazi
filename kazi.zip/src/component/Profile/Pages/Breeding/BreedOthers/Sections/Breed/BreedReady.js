import React from 'react';
import collect_cards from "../../Images/collect_cards.png";
function BreedReady(){
 return <div>
<div className="breed_box">
   <div className="container">
      <div className="row">
         <div className="col-md-12">
            <div className="breed_ready">
               <img src={collect_cards}/>
               <h4>CARD NAME</h4>
               <h5>BLACKNET</h5>
               <div className="list_box">
                  <ul>
                     <li><span>Rank:</span> Private</li>
                     <li><span>Type:</span> Gen 1</li>
                     <li><span>IQ:</span> 101</li>
                     <li><span>Potential:</span> 101</li>
                     <li><span>EQ:</span> 101</li>
                     <li><span>Wisdom:</span> 101</li>
                     <li><span>Melee:</span> 101</li>
                     <li><span>Leadership:</span> 101</li>
                     <li><span>Weapon:</span> 101</li>
                     <li><span>Feature 9:</span> 101</li>
                  </ul>
               </div>
               <div className="breed_btn">
                  <a className="btn" href="#">SELECT</a>
                  <a className="btn" href="#">EXIT LIST</a>
               </div>
            </div>
         </div>
         <div className="col-md-12">
            <div className="breed_ready">
               <img src={collect_cards}/>
               <h4>CARD NAME</h4>
               <h5>BLACKNET</h5>
               <div className="list_box">
                  <ul>
                     <li><span>Rank:</span> Private</li>
                     <li><span>Type:</span> Gen 1</li>
                     <li><span>IQ:</span> 101</li>
                     <li><span>Potential:</span> 101</li>
                     <li><span>EQ:</span> 101</li>
                     <li><span>Wisdom:</span> 101</li>
                     <li><span>Melee:</span> 101</li>
                     <li><span>Leadership:</span> 101</li>
                     <li><span>Weapon:</span> 101</li>
                     <li><span>Feature 9:</span> 101</li>
                  </ul>
               </div>
               <div className="breed_btn">
                  <a className="btn" href="#">SELECT</a>
                  <a className="btn" href="#">EXIT LIST</a>
               </div>
            </div>
         </div>
         <div className="col-md-12">
            <div className="breed_ready">
               <img src={collect_cards}/>
               <h4>CARD NAME</h4>
               <h5>BLACKNET</h5>
               <div className="list_box">
                  <ul>
                     <li><span>Rank:</span> Private</li>
                     <li><span>Type:</span> Gen 1</li>
                     <li><span>IQ:</span> 101</li>
                     <li><span>Potential:</span> 101</li>
                     <li><span>EQ:</span> 101</li>
                     <li><span>Wisdom:</span> 101</li>
                     <li><span>Melee:</span> 101</li>
                     <li><span>Leadership:</span> 101</li>
                     <li><span>Weapon:</span> 101</li>
                     <li><span>Feature 9:</span> 101</li>
                  </ul>
               </div>
               <div className="breed_btn">
                  <a className="btn" href="#">SELECT</a>
                  <a className="btn" href="#">EXIT LIST</a>
               </div>
            </div>
         </div>
         <div className="col-md-12">
            <div className="breed_ready">
               <img src={collect_cards}/>
               <h4>CARD NAME</h4>
               <h5>BLACKNET</h5>
               <div className="list_box">
                  <ul>
                     <li><span>Rank:</span> Private</li>
                     <li><span>Type:</span> Gen 1</li>
                     <li><span>IQ:</span> 101</li>
                     <li><span>Potential:</span> 101</li>
                     <li><span>EQ:</span> 101</li>
                     <li><span>Wisdom:</span> 101</li>
                     <li><span>Melee:</span> 101</li>
                     <li><span>Leadership:</span> 101</li>
                     <li><span>Weapon:</span> 101</li>
                     <li><span>Feature 9:</span> 101</li>
                  </ul>
               </div>
               <div className="breed_btn">
                  <a className="btn" href="#">SELECT</a>
                  <a className="btn" href="#">EXIT LIST</a>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
      
 </div>
 

}
export default BreedReady;