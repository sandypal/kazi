import React from 'react';
import BreedCards from '../Sections/BreedCards/BreedCards';

function BreedOtherCards(){
 return <div>
<section className="breeding_cards">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                   <div className="breed_cards_heading">
                       
               <BreedCards/>
               </div>
               </div>
               
            </div>
         </div>
      </section>
  
 </div>
 

}
export default BreedOtherCards;