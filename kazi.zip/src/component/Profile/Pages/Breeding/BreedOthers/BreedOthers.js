import React from 'react';
import BreedOthersBanner from '../BreedOthers/Sections/BreedOthersBanner';
import BreedOthersText from '../BreedOthers/Sections/BreedOthersText';
import BreedOtherCards from '../BreedOthers/Sections/BreedOtherCards';
import '../BreedOthers/BreedOthers.css';
function BreedOthers(){
 return <div>
<BreedOthersBanner/>
<BreedOthersText/>
<BreedOtherCards/>
</div>


}
export default BreedOthers;