import React from 'react';
function BreedingTaxt(){
 return <div>
<section className="breeding_text">
         <div className="container">
            <div className="row">
               <div className="col-md-6 offset-md-3">
                  <div className="breeding_link">
<a className="btn active" href="/breed-self">BREED CARDS WITH SELF</a><br></br>
<a className="btn" href="/breed-others">BREED CARDS WITH OTHERS</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
 </div>
 

}
export default BreedingTaxt;