import React from 'react';
function IndividualBanner(){
 return <div>
<div className="individual_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="individual_text">
                     <h1>Individual Card</h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
 </div>


}
export default IndividualBanner;