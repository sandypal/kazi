import React from 'react';
function BattleBanner(){
 return <div>
<div className="battle_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="battle_text">
                     <h1>Battle List</h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
 </div>
 

}
export default BattleBanner;