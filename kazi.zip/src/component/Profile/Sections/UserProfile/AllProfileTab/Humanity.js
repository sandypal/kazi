import React from 'react';
import collect_cards from "../AllProfileTab/Images/collect_cards.png";
function Humanity(){
 return <div>
<div className="profile_tab_content">
<div className="container">
<div className="row">
   <div className="col-md-12">
      <div className="profile_type">
         <ul>
            <li><a href="#">Type 1</a></li>
            <li><a href="#">Type 2</a></li>
            <li><a href="#">Type 3</a></li>
            <li><a href="#">Type 4</a></li>
            <li><a href="#">Type 5</a></li>
            <li><a href="#">Type 6</a></li>
            <li><a href="#">Type 7</a></li>
            <li><a href="#">Type 8</a></li>
         </ul>
         </div>
         </div>
   </div>
   <div className="row">
      <h2>HUMANITY</h2>
   </div>
   <div className="row">
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
       
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="profile_card_info">
            <img src={collect_cards}/>
            <h3>CARD NAME</h3>
            <div className="card_info_text">
               <div className="info_content">
                  <span>FACTION:</span><br></br>
                  <strong>BLACKNET</strong>
               </div>
               <div className="info_content">
                  <span>CARD TYPE:</span><br></br>
                  <strong>UPGRADE 1</strong>
               </div>
            </div>
            <div className="rank"><span>RANK:</span> <strong>PRIVATE</strong></div>
            <div className="card_link">
               <ul>
                  <li><a href="/battle-list">BATTLE LIST</a></li>
                  <li><a href="/breeding">BREED LIST</a></li>
                  <li><a href="/sell-cards">SELL</a></li>
               </ul>
            </div>
         </div>
      </div>
     
     
      
    
     
       
   </div>
</div>
</div>
 </div>


}
export default Humanity;