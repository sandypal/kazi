import React from 'react';
function AuctionConfirmationBanner(){
 return <div>
<div className="purchase_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="page_title">
                     <h1>AUCTION HOUSE</h1>
                  </div>
               </div>
            </div>
         </div>
      </div>
 </div>
 

}
export default AuctionConfirmationBanner;