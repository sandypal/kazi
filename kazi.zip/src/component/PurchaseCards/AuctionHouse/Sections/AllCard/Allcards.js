import React from 'react';
import blacknet1 from "../../images/blacknet1.png";
import alice from "../../images/alice.png";
function Allcards () {
	return <div>

<div className="market_box">
   <div className="row">
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={blacknet1}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div className="col-md-6">
         <div className="market_tab_text">
            <img src={alice}/>
            <h4>CARD NAME</h4>
            <div class="market_list_box">
               <ul>
                  <li>FACTION<br></br><span>BLACKNET</span></li>
                  <li>RANK<br></br><span>PRIVATE</span></li>
                  <li>PRICE: <span>50 MATIC </span><br></br>PRICE: <span>50 MATIC </span></li>
                  <li>TIME LEFT<br></br><span className="text-danger">01:40:30</span></li>
               </ul>
            </div>
            <div className="market_btn">
               <ul>
                  <li><a className="btn" href="/auction-individual">DETAILS</a></li>
                  <li><a className="btn" href="/auction-individual">NEW BID</a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</div>
     </div>
     }
     export default Allcards;