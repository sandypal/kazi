import React from 'react';
function PurchaseText () {
	return <div>
<section className="purchase_text">
         <div className="container">
            <div className="row">
              
               <div className="col-md-6 offset-md-3">
                  <div className="purchase_box text-center">
                      <a className="btn market" href="/marketplace">MARKETPLACE</a><br></br>
                      <a className="btn auction" href="/auction-house">AUCTION HOUSE</a>
                  </div>
               </div>
                
            </div>
         </div>
      </section>
    </div>
    }
    export default PurchaseText;