import React from 'react';
import AuctionBanner from '../PurchaseCards/AuctionHouse/Sections/AuctionBanner';
import AuctionTab from '../PurchaseCards/AuctionHouse/Sections/AuctionTab';
import '../PurchaseCards/PurchaseCards.css';
function AuctionHouse () {
	return <div>
	<AuctionBanner/>
	<AuctionTab/>
	</div>
}
export default AuctionHouse;