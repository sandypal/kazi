import React from 'react';
import MarketBanner from '../PurchaseCards/MarketPlace/Sections/MarketBanner';
import MarketTab from '../PurchaseCards/MarketPlace/Sections/MarketTab';
function MarketPlace () {
	return <div>
	<MarketBanner/>
	<MarketTab/>
	</div>
}
export default MarketPlace;
