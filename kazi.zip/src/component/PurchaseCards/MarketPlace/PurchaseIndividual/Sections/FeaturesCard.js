import React from 'react';
function FeaturesCard(){
 return <div>
<section className="purchase_card_details">
         <div className="container">
            <div className="row">
                <div className="col-md-12">
                <div className="features_status_purchase">
                        <h2>FEATURES</h2>
                        <ul>
                                <li><span>Type 1</span><br></br>
                                <strong>Name</strong><hr></hr><strong>90%</strong><br></br> have this feature</li>
                                <li><span>Type 2</span><br></br>
                                <strong>Name</strong><hr></hr><strong>2%</strong><br></br>have this feature</li>
                                <li><span>Type 3</span><br></br>
                                <strong>Name</strong><hr></hr><strong>10%</strong><br></br>have this feature</li>
                                <li><span>Type 4</span><br></br>
                                <strong>Name</strong><hr></hr><strong>32%</strong><br></br>have this feature</li>
                                <li><span>Type 5</span><br></br>
                                <strong>Name</strong><hr></hr><strong>82%</strong><br></br>have this feature</li>
                        </ul>
                        <ul>
                                <li><span>Type 6</span><br></br>
                                <strong>Name</strong><hr></hr><strong>90%</strong><br></br> have this feature</li>
                                <li><span>Type 7</span><br></br>
                                <strong>Name</strong><hr></hr><strong>2%</strong><br></br>have this feature</li>
                                <li><span>Type 8</span><br></br>
                                <strong>Name</strong><hr></hr><strong>10%</strong><br></br>have this feature</li>
                                <li><span>Type 9</span><br></br>
                                <strong>Name</strong><hr></hr><strong>32%</strong><br></br>have this feature</li>
                                <li><span>Type 10</span><br></br>
                                <strong>Name</strong><hr></hr><strong>82%</strong><br></br>have this feature</li>
                        </ul>
                        <ul>
                                <li><span>Type 11</span><br></br>
                                <strong>Name</strong><hr></hr><strong>90%</strong><br></br> have this feature</li>
                                <li><span>Type 12</span><br></br>
                                <strong>Name</strong><hr></hr><strong>2%</strong><br></br>have this feature</li>
                                <li><span>Type 13</span><br></br>
                                <strong>Name</strong><hr></hr><strong>10%</strong><br></br>have this feature</li>
                                <li><span>Type 14</span><br></br>
                                <strong>Name</strong><hr></hr><strong>32%</strong><br></br>have this feature</li>
                                <li><span>Type 15</span><br></br>
                                <strong>Name</strong><hr></hr><strong>82%</strong><br></br>have this feature</li>
                        </ul>
                        <ul>
                                <li><span>Type 16</span><br></br>
                                <strong>Name</strong><hr></hr><strong>90%</strong><br></br> have this feature</li>
                                <li><span>Type 17</span><br></br>
                                <strong>Name</strong><hr></hr><strong>2%</strong><br></br>have this feature</li>
                                <li><span>Type 18</span><br></br>
                                <strong>Name</strong><hr></hr><strong>10%</strong><br></br>have this feature</li>
                                <li><span>Type 19</span><br></br>
                                <strong>Name</strong><hr></hr><strong>32%</strong><br></br>have this feature</li>
                                <li><span>Type 20</span><br></br>
                                <strong>Name</strong><hr></hr><strong>82%</strong><br></br>have this feature</li>
                        </ul>
                        </div>

                    </div>
            </div>
         </div>
      </section>
    
 </div>


}
export default FeaturesCard;