import React from 'react';
import CongratulationsHero from '../PurchaseCards/AuctionHouse/AuctionCongratulations/Sections/CongratulationsHero';
import CongratulationsText from '../PurchaseCards/AuctionHouse/AuctionCongratulations/Sections/CongratulationsText';
import '../PurchaseCards/PurchaseCards.css';
function AuctionCongratulations () {
	return <div>
    <CongratulationsHero/>
	<CongratulationsText/>
	
	</div>
}
export default AuctionCongratulations;