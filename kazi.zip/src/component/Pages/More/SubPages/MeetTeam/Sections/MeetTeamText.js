import React from 'react';
import user from "../Images/user.png";
function MeetTeamText () {
	return <div>
<section className="ourteam_section">
         <div className="container">
<div className="row">
<div class="col-md-10 offset-md-1">
    <div class="team_text_section">
        <h2 class="text-center">EXTREMIS TEAM</h2>

</div>
</div>
</div>
            <div className="row align-items-center">

            <div className="col-md-4">
            <div className="team_person">
            <img src={user}/>
                <h3>PERSON NAME</h3>
                <h6>Entitled task</h6>
                </div>
            </div>
            <div className="col-md-4">
            <div className="team_person">
            <img src={user}/>
                <h3>PERSON NAME</h3>
                <h6>Entitled task</h6>
                </div>
            </div>
            <div className="col-md-4">
            <div className="team_person">
            <img src={user}/>
                <h3>PERSON NAME</h3>
                <h6>Entitled task</h6>
                </div>
            </div>
            <div className="col-md-4">
            <div className="team_person">
            <img src={user}/>
                <h3>PERSON NAME</h3>
                <h6>Entitled task</h6>
                </div>
            </div>
            <div className="col-md-4">
            <div className="team_person">
            <img src={user}/>
                <h3>PERSON NAME</h3>
                <h6>Entitled task</h6>
                </div>
            </div>
            <div className="col-md-4">
            <div className="team_person">
            <img src={user}/>
                <h3>PERSON NAME</h3>
                <h6>Entitled task</h6>
                </div>
            </div>
            </div>
         </div>
      </section>
    </div>
}
export default MeetTeamText;