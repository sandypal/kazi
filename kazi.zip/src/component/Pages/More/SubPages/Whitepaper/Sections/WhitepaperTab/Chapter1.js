import React from 'react';
import gallery_user from "../../Images/gallery_user.png";
function Chapter1 () {
	return <div>
<div className="whitepaper_list">
<ul>
   <li className="whitepaper_profile text-start">
      <div className="whitepaper_content">
         <div className="whitepaper_img">
            <img src={gallery_user}/>
         </div>
         <div className="whitepaper_name align-middle">
            <div className="align-top">
               <span># 1</span>
               <h5>Username</h5>
            </div>
            <div className="whitepaper_rank align-bottom">
               <ul>
                  <li>
                     <p>Power<br></br><span>28</span></p>
                  </li>
                  <li>
                     <p>Rarity<br></br><span>28</span></p>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </li>
</ul>
<ul>
   <li className="whitepaper_profile text-start">
      <div className="whitepaper_content">
         <div className="whitepaper_img">
            <img src={gallery_user}/>
         </div>
         <div className="whitepaper_name align-middle">
            <div className="align-top">
               <span># 1</span>
               <h5>Username</h5>
            </div>
            <div className="whitepaper_rank align-bottom">
               <ul>
                  <li>
                     <p>Power<br></br><span>28</span></p>
                  </li>
                  <li>
                     <p>Rarity<br></br><span>28</span></p>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </li>
</ul>
<ul>
   <li className="whitepaper_profile text-start">
      <div className="whitepaper_content">
         <div className="whitepaper_img">
            <img src={gallery_user}/>
         </div>
         <div className="whitepaper_name align-middle">
            <div className="align-top">
               <span># 1</span>
               <h5>Username</h5>
            </div>
            <div className="whitepaper_rank align-bottom">
               <ul>
                  <li>
                     <p>Power<br></br><span>28</span></p>
                  </li>
                  <li>
                     <p>Rarity<br></br><span>28</span></p>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </li>
</ul>
<ul>
   <li className="whitepaper_profile text-start">
      <div className="whitepaper_content">
         <div className="whitepaper_img">
            <img src={gallery_user}/>
         </div>
         <div className="whitepaper_name align-middle">
            <div className="align-top">
               <span># 1</span>
               <h5>Username</h5>
            </div>
            <div className="whitepaper_rank align-bottom">
               <ul>
                  <li>
                     <p>Power<br></br><span>28</span></p>
                  </li>
                  <li>
                     <p>Rarity<br></br><span>28</span></p>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </li>
</ul>
<ul>
   <li className="whitepaper_profile text-start">
      <div className="whitepaper_content">
         <div className="whitepaper_img">
            <img src={gallery_user}/>
         </div>
         <div className="whitepaper_name align-middle">
            <div className="align-top">
               <span># 1</span>
               <h5>Username</h5>
            </div>
            <div className="whitepaper_rank align-bottom">
               <ul>
                  <li>
                     <p>Power<br></br><span>28</span></p>
                  </li>
                  <li>
                     <p>Rarity<br></br><span>28</span></p>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </li>
</ul>     
</div>
</div>
  }
  export default Chapter1;