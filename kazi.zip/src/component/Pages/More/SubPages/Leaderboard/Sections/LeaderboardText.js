import React from 'react';
import gallery_user from "../Images/gallery_user.png";
function LeaderboardText () {
	return <div>
<section className="board_section">
         <div className="container">
            <div className="row align-items-center">
            <div className="col-md-10 offset-md-1">
                  <div className="board_text_section">
                  <h2 className="text-center">LEADERBOARD</h2>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 1</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 2</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 3</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 4</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 5</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 6</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 7</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 8</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 9</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                 <ul>
                     <li className="profile text-start">
                         <div className="profile_img"><img src={gallery_user}/></div>
                         <div className="user_name"><span># 10</span>
                         <h5>Username</h5>
                         </div>
                     </li>
                     <li className="text-end">
                         <div className="info_user">
                            <p>Total won</p>
                            <strong>28</strong>
                         </div>
                     </li>
                 </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
    </div>
}
export default LeaderboardText;