import React from 'react';
import gallery_user from "../../Images/gallery_user.png";
function Blacknet () {
	return <div>
   <div className="weapons_list">
      <ul>
         <li className="weapons_profile text-start">
            <div className="weapons_content">
               <div className="weapons_img">
                  <img src={gallery_user}/>
               </div>
               <div className="weapons_name align-middle">
                  <div className="align-top">
                     <span># 1</span>
                     <h5>Username</h5>
                  </div>
                  <div className="weapons_rank align-bottom">
                     <ul>
                        <li>
                           <p>Power<br></br><span>28</span></p>
                        </li>
                        <li>
                           <p>Rarity<br></br><span>28</span></p>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </li>
         <li className="text-end">
            <div className="product_price">
               <p>Price</p>
               <strong>10 MATIC</strong>
            </div>
         </li>
      </ul>
      <ul>
         <li className="weapons_profile text-start">
            <div className="weapons_content">
               <div className="weapons_img">
                  <img src={gallery_user}/>
               </div>
               <div className="weapons_name align-middle">
                  <div className="align-top">
                     <span># 1</span>
                     <h5>Username</h5>
                  </div>
                  <div className="weapons_rank align-bottom">
                     <ul>
                        <li>
                           <p>Power<br></br><span>28</span></p>
                        </li>
                        <li>
                           <p>Rarity<br></br><span>28</span></p>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </li>
         <li className="text-end">
            <div className="product_price">
               <p>Price</p>
               <strong>10 MATIC</strong>
            </div>
         </li>
      </ul>
      <ul>
         <li className="weapons_profile text-start">
            <div className="weapons_content">
               <div className="weapons_img">
                  <img src={gallery_user}/>
               </div>
               <div className="weapons_name align-middle">
                  <div className="align-top">
                     <span># 1</span>
                     <h5>Username</h5>
                  </div>
                  <div className="weapons_rank align-bottom">
                     <ul>
                        <li>
                           <p>Power<br></br><span>28</span></p>
                        </li>
                        <li>
                           <p>Rarity<br></br><span>28</span></p>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </li>
         <li className="text-end">
            <div className="product_price">
               <p>Price</p>
               <strong>10 MATIC</strong>
            </div>
         </li>
      </ul>
      <ul>
         <li className="weapons_profile text-start">
            <div className="weapons_content">
               <div className="weapons_img">
                  <img src={gallery_user}/>
               </div>
               <div className="weapons_name align-middle">
                  <div className="align-top">
                     <span># 1</span>
                     <h5>Username</h5>
                  </div>
                  <div className="weapons_rank align-bottom">
                     <ul>
                        <li>
                           <p>Power<br></br><span>28</span></p>
                        </li>
                        <li>
                           <p>Rarity<br></br><span>28</span></p>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </li>
         <li className="text-end">
            <div className="product_price">
               <p>Price</p>
               <strong>10 MATIC</strong>
            </div>
         </li>
      </ul>
      <ul>
         <li className="weapons_profile text-start">
            <div className="weapons_content">
               <div className="weapons_img">
                  <img src={gallery_user}/>
               </div>
               <div className="weapons_name align-middle">
                  <div className="align-top">
                     <span># 1</span>
                     <h5>Username</h5>
                  </div>
                  <div className="weapons_rank align-bottom">
                     <ul>
                        <li>
                           <p>Power<br></br><span>28</span></p>
                        </li>
                        <li>
                           <p>Rarity<br></br><span>28</span></p>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </li>
         <li className="text-end">
            <div className="product_price">
               <p>Price</p>
               <strong>10 MATIC</strong>
            </div>
         </li>
      </ul>
   </div>
</div>
  }
  export default Blacknet;