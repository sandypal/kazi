import React from 'react';
import AboutBanner from '../About/Sections/AboutBanner';
import '../About/About.css';
function About () {
	return <div>
		<AboutBanner/>
	</div>
}
export default About;
