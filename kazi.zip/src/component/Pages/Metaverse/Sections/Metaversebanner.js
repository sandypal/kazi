import React from 'react';
function Metaversebanner () {
	return <div>
<div className="Page_metaverse_section">
         <div className="container">
            <div className="row">
               <div className="col-md-12">
                  <div className="page_title">
                     
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
}
export default Metaversebanner;