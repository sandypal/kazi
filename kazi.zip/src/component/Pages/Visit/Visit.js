import React from 'react';
import VisitBanner from '../Visit/Sections/VisitBanner';
import '../Visit/Visit.css';
function Visit () {
	return <div>
		<VisitBanner/>
	</div>
}
export default Visit;
