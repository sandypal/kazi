import React from 'react';
function Chapters1 () {
	return <div>
<h4>Chapter 7: The Doctor</h4>
     <p>Amidst all the chaos of the powerful, menacing, and dangerous storm that blotted out the blazing sun and cast shadows down the mountain side, breathed another soul that was not concerned with the raging rainstorm outside because a much bigger hurricane was brewing inside his head.</p>
      <p>Here, an abundance of mountains lay in Far away in the land of mountains, where few lives
      existed except for famished wild snow leopards, mountain goats, and golden eagles, raged a
      storm which grew to such a thing of force and fury that even the tips of mountains,</p>
      <p>coated with months of old ice, shook with vengeance. The whole world seemed unnaturally dark, as if all the
      light in the world had been sucked out...(continued)</p>
      </div>
      }
      export default Chapters1;